import 'package:flutter/material.dart';
import 'package:flutter_web_auth/flutter_web_auth.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'You have pushed the button this many times:',
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headline4,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()async{
          var result = await FlutterWebAuth.authenticate(
           //url: 'https://login.microsoftonline.com/common/oauth2/authorize?client_id=5e38f8fb-9c29-4c98-995f-da66c9b2fd57&redirect_uri=https%3A%2F%2Fauth.teo-intl.com%2Fsignin-oidc&response_type=id_token&scope=openid%20profile&response_mode=form_post&nonce=637744598163525724.NjU4N2JiOTUtYmEyYy00ZjQyLTgzZmEtZTJkMGQ0MzhhYmNmMDBmZWZhMDgtNzE1Zi00NTMwLWEyOGQtZDEyNzc5MWFiNWU5&state=CfDJ8GD6NxtlLIpEqhDoQxI4OCPf6hABHOYMqT_9ylazWvmBHqwCPIBvDjOyrnugjLOK9Q2luvnqy1gJdzWdgoVX2HNaF8otcKqqFNeORJV-Mh_G4p44dmg8FC08yPPuzPWWl2HUOqW32L2IR15Sor6oG0SNiUcThNWylBjPhV55Yh5cUPIDI1GJ9jZ0_I_Xv3ZPusV9m7FbbQwf_6OnTi-cJdL3gNgRSxHPxtTy6N7GVLEGrsl5nsddV2xioLQvV248wiXFGaysVIIEZLpYYY87na7e4ojdbduIy8nIqF9-kHd33r_UECdJNJYQ1dNCtbvUoybFMYajIOXXnDhxdonKPvp3V1T4tNbLP8RgzwINbeVF5zHKwnR82NaXLbBCnHWIRzCJXorQ9hndy3snEU34MmRVYuGUkdAtvozDMn4gOpwliLpmmlkbukRW7LXjiQ6zhETrXH4-P_g3aiNRG4Fbszukt3rcvMYhHwLDHPOaLQvtaz8kv6z-4dRf7Krl_O-e1rMJWI8XHCf8zXxXCgBK7y4HWN4fk8aP0Sgy408qLnutvorWvSHf4uSjqpoqMxgu6Atehyr903U_PFTkmycOuyGXHggwDjMZAWQDyzelTP-PQay41rt9T3LbLV319q9Yw4phr2uuLFjfTNNMUMesAV0B439K-63oL35jCublFXQAe43dgcAqmdhxnVvh2gHqHvA5lsOGMNGuLdALcpkfbZJ2-GoIle8tVDRD65mjvDgQPPaOMF-l4c5E4wGVrLLdA_XlIpXPth7FxqqmitZfUCerMWEsKNlX9yrOCKiL6iDwYgavJ_okevAqmzZngYR8qMOiR5yL3QdW6N0m2n6vtrfEkI9MimWJPwaxO74e6vGS',
           url: "https://auth.teo-intl.com/connect/authorize?client_id=1CB07952-B8EC-4433-9CC0-BD062F2F519A&scope=TOSSAPI%20offline_access&response_type=code&redirect_uri=oauth%3A%2F%2Ftoss&nonce=81387052-6182-486a-9e75-b9b9985a4d63",
              callbackUrlScheme: "oauth://toss");

          final token = Uri.parse(result).queryParameters['token'];

        },

        // https://staging-tossauth.teo-intl.com/connect/authorize?response_type=token&client_id=C06EB280-01D6-420D-B811-CBC29DCD609C&redirect_uri=http://localhost/item-requisition/public/access-token&scope=TOSSAPI&state=2321aa6eb0bb4ae08fc45e9d87e9e14f


        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
