package com.example.ms_office_login_with_web_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
